<!-- Footer -->
<footer class="main">
	&copy; 2016 <strong>LocationEvent</strong>
	<br>
	Developed by
	<a href="mailto:kgom1028@hotmail.com" target="_blank">KGOM1028</a>
</footer>
